-- First register a normal student account through the website.
-- Then run this query, replacing the email with the account you want to make administrator:
UPDATE users SET role='ADMIN' WHERE email='your-email@campus.edu';
