-- Optional sample records (run after registering/promoting an account).
-- Replace 1 with the actual user ID, or leave created_by NULL.
INSERT INTO items(title,description,category,item_status,location_found,contact,image_name,created_by)
VALUES
('Blue water bottle','Blue reusable bottle with a small sticker.','Personal items','FOUND','Library, first floor','helpdesk@campus.edu','bottle.png',NULL),
('Student notebook','Black notebook with lecture notes inside.','Books & stationery','LOST','Engineering Block','helpdesk@campus.edu','notebook.png',NULL),
('Set of keys','Three keys on a round keyring.','Personal items','FOUND','Cafeteria','helpdesk@campus.edu','keys.png',NULL),
('Wireless earbuds','White earbuds in a charging case.','Electronics','LOST','Computer Lab','helpdesk@campus.edu','earbuds.png',NULL);
