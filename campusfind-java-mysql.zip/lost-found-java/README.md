# CampusFind — Lost & Found (Java + HTML + MySQL)

A beginner-friendly campus lost-and-found website using **Java Spring Boot** for the backend, **HTML + Thymeleaf + CSS** for the frontend, and **MySQL** for the database. The layout is inspired by the supplied CampusFind interface and includes the supplied item illustrations.

## Features
- Home page with search, Lost/Found filters, statistics and item cards.
- Student registration and sign-in.
- Separate Student and Administrator account selection.
- Students can report lost or found items.
- Administrator dashboard can update an item to LOST, FOUND or RETURNED and view registered accounts.
- Uses session-based sign-in and MySQL tables.

## Requirements
- Java 17+
- Maven 3.8+
- MySQL 8+

## Run it
1. Extract the ZIP.
2. Create a MySQL user/database, or use a local MySQL account.
3. Open `src/main/resources/application.properties` and change `spring.datasource.username` and `spring.datasource.password` to your MySQL credentials.
4. Start MySQL.
5. In this project folder run:
   ```bash
   mvn spring-boot:run
   ```
6. Open `http://localhost:8080`.

The database `lost_found` is created automatically by the JDBC URL. `schema.sql` creates the tables.

## Create the administrator account
For safety, the app does **not** silently create a public admin account. After starting the app and registering a student, use MySQL Workbench or the MySQL command line to promote the intended account:
```sql
UPDATE users SET role='ADMIN' WHERE email='your-email@campus.edu';
```
Then sign out and sign in again, choosing **Administrator account**.

## Beginner notes
- `AppController.java` contains the web routes and SQL calls.
- `Item.java` is the simple model for a reported item.
- `templates/` contains the HTML pages.
- `static/css/style.css` contains all page styling.
- `schema.sql` creates the database tables.
- Passwords are plain text in this educational starter version. **Do not use this as-is for real users or public deployment.** Before real deployment, use Spring Security + BCrypt, validation, CSRF protection, and a managed database.

## Deploying
This is a Java server application, not a static-only Vercel site. Deploy it to a Java-capable host (for example, Render or Railway) and use a managed MySQL database. Vercel alone cannot run this Spring Boot application as a traditional always-on Java server.
